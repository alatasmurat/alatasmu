﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Xml.Linq;
using System.Xml.Serialization;
using Microsoft.AspNetCore.Mvc;
using readTheXml6.Models;

namespace readTheXml6.Controllers
{
    public class HomeController : Controller
    {
        //FileStream fs = new FileStream("wordsMobyDick.xml", FileMode.Open);
        //XmlSerializer serializer = new XmlSerializer(typeof(List<Words>), new XmlRootAttribute("wordsCollection"));
        public IActionResult Index()
        {
            try
            {
                //List<Words> words = (List<Words>)serializer.Deserialize(fs);
                //fs.Close();


                XDocument doc = XDocument.Load(@"wordsMobyDick.xml");
                var query = (from q in doc.Element("wordsCollection").Elements("wordsArray").Elements("word")
                             orderby int.Parse(q.Element("count").Value) descending
                             select new Words
                             {
                                 count = int.Parse(q.Element("count").Value),
                                 word = q.Element("word_x0020_text").Value
                             })
                            .Take(10);


                return View(query);
            }
            catch
            {
                throw;
            }
        }
        
    }
}
