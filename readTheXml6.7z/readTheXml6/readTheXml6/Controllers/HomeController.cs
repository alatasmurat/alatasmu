﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;
using Microsoft.AspNetCore.Mvc;
using readTheXml6.Models;

namespace readTheXml6.Controllers
{
    public class HomeController : Controller
    {
        //FileStream fs = new FileStream("wordsMobyDick.xml", FileMode.Open);
        //XmlSerializer serializer = new XmlSerializer(typeof(List<Words>), new XmlRootAttribute("wordsCollection"));
        public IActionResult Index()
        {
            try
            {
                //List<Words> words = (List<Words>)serializer.Deserialize(fs);
                //fs.Close();


                List<Words> words = new List<Words>();
                
                XmlDocument doc = new XmlDocument();
                doc.Load("wordsMobyDick.xml");

                foreach (XmlNode node in doc.SelectNodes("/wordsCollection/wordsArray/word"))
                {
                    words.Add(new Words
                    {
                        count = int.Parse(node["count"].InnerText),
                        word = node["word_x0020_text"].InnerText
                    });

                }
                

                return View(words);
            }
            catch
            {
                throw;
            }
        }
        
    }
}
