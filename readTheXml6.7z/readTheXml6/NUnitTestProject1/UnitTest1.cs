using NUnit.Framework;
using readTheXml6.Controllers;

namespace Tests
{
    public class HomeControllerTests
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public void ShouldReturnView()
        {
            string expected = "Index";
            HomeController controller = new HomeController();
            var result = controller.Index() as ViewResult;
            Assert.AreEqual(expected, result.ViewName);

        }
    }
}