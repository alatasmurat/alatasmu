﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Http;
using System.Text.RegularExpressions;
using System.Xml;
using System.Xml.Serialization;
using System.IO;
using System.Runtime.Serialization;
using System.Data;

namespace wordsMobyDick
{
    public class Program
    {
        static void Main(string[] args)
        {
            Task t = new Task(DownloadMobyDick);
            t.Start();
            Console.WriteLine("Downloading page and saving the result in an xml file... wait a minute");
            Console.ReadLine();

        }

        static async void DownloadMobyDick()
        {
            string BaseUri = "http://www.gutenberg.org/files/2701/2701-0.txt";

            using (HttpClient client = new HttpClient())
            using (HttpResponseMessage response = await client.GetAsync(BaseUri))
            using (HttpContent content = response.Content)
            {
                string result = await content.ReadAsStringAsync();//result dizisine icerigi cekiyor

                string[] stopWordsList = File.ReadAllLines("EnglishStopwords.txt");
                foreach (string stopWord in stopWordsList)//bu kisim uygulamayi biraz yavaslatti, islemesi 1 dk'yi buluyor, textte gecen ingilizcedeki Stopwords'leri cikardigim kisim
                {
                    string regexp = @"(?i)\s?\b" + stopWord + @"\b\s?";
                    result = Regex.Replace(result, regexp, " ");
                }

                var wordsMD = new Dictionary<string, int>(StringComparer.InvariantCultureIgnoreCase);
                countWordsInFile(result, wordsMD);

            }
        }

        static void countWordsInFile(string file, Dictionary<string, int> wordsMD)
        {
            var wordPattern = new Regex(@"[A-Za-z’-]+");

            List<string> pieces = new List<string>();
            foreach (Match match in wordPattern.Matches(file))//texten kelimeleri(patterni) ayirip herbirini kucuk harfe donusturuyor, kelime sayimi yapan kisim 
            {
                pieces.Add(match.ToString().ToLowerInvariant());
                int currentCount = 0;
                wordsMD.TryGetValue(match.Value, out currentCount);

                currentCount++;
                wordsMD[match.Value] = currentCount;
            }

            var hash = new HashSet<string>(pieces);// ayni kelime tekrar ediyorsa tekrarlari silip diziye atiyor
            string[] pieces2 = hash.ToArray();

            /*for (int i = 0; i < pieces2.Length; i++)
            {
                Console.WriteLine(pieces2[i] + " = " + wordsMD[pieces2[i]]);
            }*/

            //butun kelimeleri ve sayilarini string seklinde iceren Word sınıfından turemis nesne, words 
            Word[] word = new Word[pieces2.Length];
            for (int p = 0; p < pieces2.Length; p++)
            {
                word[p] = new Word(pieces2[p], wordsMD[pieces2[p]].ToString());
            }
            WordsArray words = new WordsArray(pieces2.Length);
            for (int p = 0; p < pieces2.Length; p++)
            {
                words[p] = word[p];
            }

            FileStream fs = new FileStream("wordsMobyDick.xml", FileMode.Create);
            XmlSerializer s = new XmlSerializer(typeof(WordsArray));
            s.Serialize(fs, words);
            fs.Close();

            Console.Write("\nCreated an xml file.");
            System.Diagnostics.Process.Start("wordsMobyDick.xml");


        }
        public class Word
        {
            [XmlElement("word text")]
            public string Text;
            [XmlElement("count")]
            public string TextCount;

            public Word() { }

            public Word(string text, string count)
            {
                Text = text;
                TextCount = count;
            }
        }

        [XmlRoot("wordsCollection")]
        public class WordsArray //xml'i yazma
        {
            private Word[] _WordsList = null;

            public WordsArray() { }

            public WordsArray(int size)
            {
                _WordsList = new Word[size];
            }

            [XmlArray("wordsArray")]
            [XmlArrayItem("word")]
            public Word[] WordsCollection
            {
                get
                {
                    return _WordsList;
                }
                set
                {
                    _WordsList = value;
                }
            }
            public Word this[int index]
            {
                get
                {
                    if (index <= _WordsList.GetUpperBound(0) || index > -1)
                        return (Word)_WordsList[index];
                    else
                        throw new IndexOutOfRangeException("Invalid index value passed.");
                }
                set
                {
                    if (index <= _WordsList.GetUpperBound(0) || index > -1)
                        _WordsList[index] = value;
                    else
                        throw new IndexOutOfRangeException("Invalid index value passed.");
                }
            }
        }
    }
}
